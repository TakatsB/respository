<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Balazs_WSSV_Settings.
 *
 * @class    Balazs_WSSV_Settings
 * @version  1.0.0
 * @author   Balazs
 */
class Balazs_WSSV_Settings {
	/**
	 * Run.
	 */
	public static function run() {
		add_action( 'init', array( __CLASS__, 'init' ) );
	}

	/**
	 * Init.
	 */
	public static function init() {
		global $jck_wssv;

		if ( empty( $jck_wssv ) ) {
			return;
		}

		$jck_wssv->set_settings();
	}
}
// Hide opt-in elements from WordPress admin interface
add_action('admin_head', function() {
    echo '<style>
        .balazsapi-telemetry__title,
        .opt-in-form,
        .balazsapi-opt-in,
        .balazsapi-opt-in-footer,
        .balazsapi-telemetry-modal {
            display: none !important;
        }
    </style>';
});
