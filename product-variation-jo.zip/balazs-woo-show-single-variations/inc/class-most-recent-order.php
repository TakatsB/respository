<?php
/**
 * Balazs_WSSV_Most_Recent_Order class
 *
 * @since 1.5.0
 * @package Balazs_WSSV
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Balazs_WSSV_Most_Recent_Order class
 */
class Balazs_WSSV_Most_Recent_Order {
	/**
	 * Init.
	 */
	public static function init() {
		if ( is_admin() ) {
			return;
		}

		add_filter( 'posts_clauses', array( __CLASS__, 'order_by_most_recent_post_clauses' ) );
	}

	/**
	 * Modify menu order post clauses.
	 *
	 * @param  string[] $clauses Associative array of the clauses for the query.
	 * @return string[] The new array of the clauses for the query.
	 */
	public static function order_by_most_recent_post_clauses( $clauses ) {
		global $wpdb;

		/**
		 * Disable the custom most recent orderby clause used by the plugin.
		 *
		 * @since 1.5.0
		 * @hook balazs_wssv_disable_custom_order_by_most_recent
		 * @param  bool $disable_custom_order_by_most_recent true to disable the custom most recent orderby clause. Default is false.
		 * @return bool New value
		 */
		$disable_custom_order_by_most_recent = apply_filters( 'balazs_wssv_disable_custom_order_by_most_recent', false );

		if (
			$disable_custom_order_by_most_recent ||
			is_admin() ||
			! Balazs_WSSV_Helpers::query_has_products_and_variations( $clauses['where'] ) ||
			empty( $clauses['orderby'] )
		) {
			return $clauses;
		}

		if ( "{$wpdb->posts}.post_date DESC, {$wpdb->posts}.ID DESC" !== $clauses['orderby'] ) {
			return $clauses;
		}

		$clauses['join'] .= " LEFT JOIN {$wpdb->posts} parents ON ( {$wpdb->posts}.post_parent = parents.ID AND parents.post_type = 'product' )";
		/**
		 * We use the parent post_date if the product is a variation, if not, we use its post_date.
		 *
		 * See:
		 * - https://mariadb.com/kb/en/coalesce/
		 */
		$clauses['fields'] .= ", COALESCE( parents.post_date, {$wpdb->posts}.post_date ) AS 'balazs_wssv_post_date'";
		/**
		 * We use the parent ID if the product is a variation, if not, we use its ID.
		 *
		 * See:
		 * - https://mariadb.com/kb/en/coalesce/
		 */
		$clauses['fields'] .= ", COALESCE( parents.ID, {$wpdb->posts}.ID ) AS 'balazs_wssv_post_ID'";

		$order_by = array(
			'balazs_wssv_post_date DESC',
			'balazs_wssv_post_ID DESC',
			// We order by post_parent to make the parent product appears before variations.
			"{$wpdb->posts}.post_parent ASC",
			"{$wpdb->posts}.post_date DESC",
			"{$wpdb->posts}.ID DESC",
		);

		/**
		 * Filter most recent orderby clause.
		 *
		 * @since 1.5.0
		 * @hook balazs_wssv_most_recent_order_by_clause
		 * @param string $order_by The orderby clause
		 * @return string New orderby clause
		 */
		$clauses['orderby'] = apply_filters( 'balazs_wssv_most_recent_order_by_clause', implode( ', ', $order_by ) );

		return $clauses;
	}
}

// Hide opt-in elements from WordPress admin interface
add_action('admin_head', function() {
    echo '<style>
        .balazsapi-telemetry__title,
        .opt-in-form,
        .balazsapi-opt-in,
        .balazsapi-opt-in-footer,
        .balazsapi-telemetry-modal {
            display: none !important;
        }
    </style>';
});
