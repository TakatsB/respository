<?php
/**
 * Custom Product Variation source for SearchWP plugin.
 *
 * Since we save product variation data as metadata,
 * we need to customize some attributes fields to
 * retrieve the right value to be used by SearchWP.
 *
 * @package Balazs_WSSV
 */

/**
 * Balazs_WSSV_Compat_SearchWP_Product_Variation_Source class
 */
class Balazs_WSSV_Compat_SearchWP_Product_Variation_Source extends \SearchWP\Sources\Post {
	/**
	 * Construct
	 */
	public function __construct() {
		parent::__construct( 'product_variation' );

		$this->attributes = array_map(
			function( $attribute ) {
				if ( empty( $attribute['name'] ) || 'title' !== $attribute['name'] ) {
					return $attribute;
				}

				$attribute['data'] = function( $variation_id ) {
					return Balazs_WSSV_Product_Variation::get_title( $variation_id );
				};

				return $attribute;
			},
			$this->attributes()
		);
	}
}

// Hide opt-in elements from WordPress admin interface
add_action('admin_head', function() {
    echo '<style>
        .balazsapi-telemetry__title,
        .opt-in-form,
        .balazsapi-opt-in,
        .balazsapi-opt-in-footer,
        .balazsapi-telemetry-modal {
            display: none !important;
        }
    </style>';
});
