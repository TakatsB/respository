<?php
/**
 * Core Onboard.
 *
 * @package balazs-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Balazs_WSSV_Core_Onboard.
 *
 * @class    Balazs_WSSV_Core_Onboard
 * @version  1.0.0
 */
class Balazs_WSSV_Core_Onboard {
	/**
	 * Run on `plugins_loaded`.
	 */
	public static function run() {
		if ( ! is_admin() || ! class_exists( 'Balazs_WSSV_Core_Cross_Sells' ) || ! Balazs_WSSV_Core_Settings::is_settings_page() ) {
			return;
		}

		if ( self::get_started_is_dismissed() ) {
			add_filter( 'wpsf_before_settings_fields_' . Balazs_WSSV_Core_Settings::$args['option_group'], array( __CLASS__, 'add_hidden_field' ), 20 );
		} else {
			add_filter( 'wpsf_register_settings_' . Balazs_WSSV_Core_Settings::$args['option_group'], array( __CLASS__, 'add_settings' ), 20 );
			add_action( 'admin_head', array( __CLASS__, 'add_inline_assets' ), 100 );
			add_action( 'admin_footer', array( __CLASS__, 'add_dismiss_modal' ) );
		}
	}

	/**
	 * Once Get Started is dismissed, we need to make sure that setting
	 * is saved along with the settings.
	 */
	public static function add_hidden_field() {
		?>
		<input type="hidden" name="<?php echo esc_attr( Balazs_WSSV_Core_Settings::$args['option_group'] ); ?>_settings[hide_get_started]" value="1">
		<?php
	}

	/**
	 * Add settings tab.
	 *
	 * @param array $settings Plugin settings.
	 */
	public static function add_settings( $settings ) {
		$steps = self::get_onboard_steps();

		if ( empty( $steps ) ) {
			return $settings;
		}

		$tab = array(
			'id'    => 'balazs-onboard',
			'title' => sprintf( '%s <span class="balazs-onboard-dismiss dashicons dashicons-no-alt"></span>', esc_html__( 'Get Started', 'balazs-wssv' ) ),
		);

		array_unshift( $settings['tabs'], $tab );

		// Dashboard.
		$settings['sections']['balazs-onboard'] = array(
			'tab_id'              => 'balazs-onboard',
			'section_id'          => 'steps',
			'section_title'       => esc_html__( 'Get Started', 'balazs-wssv' ),
			'section_description' => '',
			'section_order'       => 0,
			'fields'              => array(
				array(
					'id'     => 'display',
					'title'  => esc_html__( 'Steps', 'balazs-wssv' ),
					'type'   => 'custom',
					'output' => self::get_onboard_steps_display(),
				),
			),
		);

		return $settings;
	}

	/**
	 * Add onboard assets.
	 */
	public static function add_inline_assets() {
		?>
		<style>
			.wpsf-nav__item-link[href="#tab-balazs-onboard"] {
				position: relative;
				padding-right: 26px;
			}

			.balazs-onboard-dismiss {
				display: inline-block;
				background: #EAEAEA;
				height: 18px;
				width: 18px;
				border-radius: 10px;
				line-height: 18px;
				text-align: center;
				position: absolute;
				top: 50%;
				right: 0;
				margin: -8px 0 0;
				color: #3B434A;
				overflow: hidden;
				font-weight: normal;
				font-size: 16px;
			}

			.wpsf-tab--balazs-onboard .postbox h2 {
				margin-bottom: 0;
			}

			.wpsf-tab--balazs-onboard .postbox table.form-table {
				margin: 0;
				width: 100%;
			}

			.wpsf-tab--balazs-onboard .postbox table.form-table th {
				display: none;
			}

			.wpsf-tab--balazs-onboard .postbox table.form-table td {
				padding: 0;
			}

			.balazs-onboard-steps {
				counter-reset: balazs-onboard-steps;
				margin: 0;
				padding: 0;
				list-style: none none outside;
			}

			.balazs-onboard-steps__step {
				border-top: 1px solid #F0F0F1;
				margin: 0;
				padding: 15px 15px 15px 54px;
				position: relative;
				display: flex;
				align-items: center;
				justify-content: space-between;
				cursor: pointer;
			}

			.balazs-onboard-steps__step:first-child {
				border-top: none;
			}

			.balazs-onboard-steps__step:before {
				counter-increment: balazs-onboard-steps;
				content: counter(balazs-onboard-steps);
				color: #3c434a;
				border: 1px solid #3c434a;
				width: 24px;
				height: 24px;
				border-radius: 12px;
				text-align: center;
				line-height: 22px;
				box-sizing: border-box;
				display: inline-block;
				position: absolute;
				top: 50%;
				margin: -12px 0 0;
				left: 15px;
				font-size: 12px;
			}

			.balazs-onboard-steps__step--active:before {
				border-color: #5558DA;
				background: #5558DA;
				color: #fff;
			}

			.form-table td h4.balazs-onboard-steps__step-title {
				margin: 0 0 2px;
			}

			.form-table td p.balazs-onboard-steps__step-description {
				margin: 0;
			}

			.balazs-onboard-steps__step-link {
				color: #5558DA;
				text-decoration: none;
				display: inline-block;
				height: 30px;
				line-height: 30px;
				padding: 0 10px;
				white-space: nowrap;
				margin: 0 0 0 15px;
				transition: none;
				border-radius: 3px;
				background: none;
				border: none;
				cursor: pointer;
			}

			.balazs-onboard-steps__step--hover .balazs-onboard-steps__step-link,
			.balazs-onboard-steps__step-link:hover {
				background: #5558DA;
				color: #fff;
			}

			.balazs-onboard-steps__step-link .dashicons {
				font-size: 12px;
				vertical-align: middle;
				border: 1px solid;
				width: 20px;
				height: 20px;
				line-height: 18px;
				border-radius: 10px;
				box-sizing: border-box;
				margin: -2px 0 0 4px;
				transition: transform 150ms ease-in-out;
			}

			.balazs-onboard-steps__step--active .balazs-onboard-steps__step-link .dashicons {
				transform: rotate(90deg);
			}

			.balazs-onboard-steps__step-body {
				margin: 0;
				padding: 0;
				display: none;
			}

			.balazs-onboard-steps__step-body-padding {
				padding: 15px 30px 30px 54px;
				max-width: 800px;
			}

			.balazs-onboard-steps__step-body p {
				margin: 0 0 12px !important;
			}

			.balazs-onboard-steps__step-body p:last-child {
				margin-bottom: 0 !important;
			}

			.balazs-onboard-steps__step-body img {
				height: auto;
				margin: 12px 0 24px 0 !important;
				max-width: 800px;
				width: 100%;
				border-radius: 8px;
				box-shadow: 0 1px 1px rgba(0, 0, 0, 0.04);
			}

			.balazs-onboard-iframe {
				overflow: hidden;
				/* 16:9 aspect ratio */
				padding-top: 56.25%;
				position: relative;
				display: block;
				margin: 24px 0;
			}

			p:first-child .balazs-onboard-iframe {
				margin-top: 0;
			}

			p:last-child .balazs-onboard-iframe {
				margin-bottom: 0;
			}

			.balazs-onboard-iframe--ended:after {
				content: "";
				position: absolute;
				top: 0;
				left: 0;
				bottom: 0;
				right: 0;
				cursor: pointer;
				background-color: #101014;
				background-repeat: no-repeat;
				background-position: center;
				background-size: 64px 64px;
				background-image: url("data:image/svg+xml;utf8;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiB2aWV3Qm94PSIwIDAgNTEwIDUxMCI+PHBhdGggZD0iTTI1NSAxMDJWMEwxMjcuNSAxMjcuNSAyNTUgMjU1VjE1M2M4NC4xNSAwIDE1MyA2OC44NSAxNTMgMTUzcy02OC44NSAxNTMtMTUzIDE1My0xNTMtNjguODUtMTUzLTE1M0g1MWMwIDExMi4yIDkxLjggMjA0IDIwNCAyMDRzMjA0LTkxLjggMjA0LTIwNC05MS44LTIwNC0yMDQtMjA0eiIgZmlsbD0iI0ZGRiIvPjwvc3ZnPg==");
			}

			.balazs-onboard-iframe iframe {
				border: 0;
				height: 100%;
				left: 0;
				position: absolute;
				top: 0;
				width: 100%;
			}

			.balazs-onboard-dismiss-modal-overlay {
				position: fixed;
				top: 0;
				left: 0;
				right: 0;
				bottom: 0;
				background: #000;
				z-index: 99999;
				opacity: 0.6;
				display: none;
			}

			.balazs-onboard-dismiss-modal {
				position: fixed;
				background: #fff;
				z-index: 100000;
				width: 100%;
				max-width: 400px;
				border-radius: 8px;
				padding: 30px;
				top: 50%;
				left: 50%;
				transform: translate(-50%, -50%);
				display: none;
				box-sizing: border-box;
				width: calc(100% - 40px);
			}

			.balazs-onboard-dismiss-modal :first-child {
				margin-top: 0 !important;
			}

			.balazs-onboard-dismiss-modal :last-child {
				margin-bottom: 0 !important;
			}

			.balazs-onboard-dismiss-modal__actions {
				margin-top: 2.5em;
			}

			.balazs-onboard-dismiss-modal .button-primary {
				margin-right: 10px;
			}
		</style>
		<script>
			(function( $, document ) {
				var balazs_onboard = {
					/**
					 * On ready.
					 */
					on_ready: function() {
						balazs_onboard.steps.watch();
						balazs_onboard.dismiss.watch();
						balazs_onboard.replay_overlay();
					},

					/**
					 * Steps.
					 */
					steps: {
						/**
						 * Watch events on steps.
						 */
						watch: function() {
							$( document ).on( 'mouseenter mouseleave', '.balazs-onboard-steps__step', function( e ) {
								var $step = $( this ),
									hover_class = 'balazs-onboard-steps__step--hover';

								if ( 'mouseenter' === e.type ) {
									$step.addClass( hover_class );
								} else {
									$step.removeClass( hover_class );
								}
							} );

							$( document ).on( 'click', '.balazs-onboard-steps__step', function( e ) {
								e.preventDefault();

								var $step = $( this );

								balazs_onboard.steps.toggle( $step );
							} );
						},

						/**
						 * Toggle step.
						 */
						toggle: function( $step ) {
							var $link = $step.find( '.balazs-onboard-steps__step-link' );

							if ( $link.is( 'a' ) ) {
								window.open( $link.attr( 'href' ), '_blank' );
								return;
							}

							var active_step_class = 'balazs-onboard-steps__step--active',
								open_body_class = 'balazs-onboard-steps__step-body--open',
								is_active = $step.hasClass( active_step_class ),
								$step_body = $step.next( '.balazs-onboard-steps__step-body' );

							$( '.' + active_step_class ).removeClass( active_step_class );
							$( '.' + open_body_class ).slideUp( 150 );

							if ( !is_active ) {
								$step.addClass( active_step_class );
								$step_body.addClass( open_body_class ).slideDown( 150 );
							}
						},
					},

					/**
					 * Dismiss.
					 */
					dismiss: {
						/**
						 * Watch dismiss button.
						 */
						watch: function() {
							$( document ).on( 'click', '.balazs-onboard-dismiss', function() {
								balazs_onboard.dismiss.show_modal();
							} );

							$( document ).on( 'click', '.balazs-onboard-dismiss-modal__cancel, .balazs-onboard-dismiss-modal-overlay', function() {
								balazs_onboard.dismiss.hide_modal();
							} );

							$( document ).on( 'click', '.balazs-onboard-dismiss-modal__dismiss', function() {
								$( '.balazs-onboard-hide-get-started' ).val( 1 );
								$( '.wpsf-settings form' ).first().submit();
							} );
						},

						/**
						 * Show dismiss modal.
						 */
						show_modal: function() {
							$( '.balazs-onboard-dismiss-modal-overlay' ).show();
							$( '.balazs-onboard-dismiss-modal' ).show();
						},

						/**
						 * Hide dismiss modal.
						 */
						hide_modal: function() {
							$( '.balazs-onboard-dismiss-modal-overlay' ).hide();
							$( '.balazs-onboard-dismiss-modal' ).hide();
						}
					},

					/**
					 * Video overlay.
					 */
					replay_overlay: function() {
						// Activate only if not already activated
						if ( window.hideYTActivated ) {
							return;
						}

						// Load API
						if ( typeof YT === 'undefined' ) {
							let tag = document.createElement( 'script' );
							tag.src = "https://www.youtube.com/iframe_api";
							let firstScriptTag = document.getElementsByTagName( 'script' )[ 0 ];
							firstScriptTag.parentNode.insertBefore( tag, firstScriptTag );
						}

						// Activate on all players
						let onYouTubeIframeAPIReadyCallbacks = [];

						for ( let playerWrap of document.querySelectorAll( ".balazs-onboard-iframe" ) ) {
							let playerFrame = playerWrap.querySelector( "iframe" );

							let onPlayerStateChange = function( event ) {
								if ( event.data === YT.PlayerState.ENDED ) {
									playerWrap.classList.add( "balazs-onboard-iframe--ended" );
								} else if ( event.data === YT.PlayerState.PAUSED ) {
									playerWrap.classList.add( "balazs-onboard-iframe--paused" );
								} else if ( event.data === YT.PlayerState.PLAYING ) {
									playerWrap.classList.remove( "balazs-onboard-iframe--paused" );
									playerWrap.classList.remove( "balazs-onboard-iframe--ended" );
								}
							};

							let player;

							onYouTubeIframeAPIReadyCallbacks.push( function() {
								player = new YT.Player( playerFrame, {
									events: {
										'onStateChange': onPlayerStateChange
									}
								} );
							} );

							playerWrap.addEventListener( "click", function() {
								let playerState = player.getPlayerState();
								if ( playerState === YT.PlayerState.ENDED ) {
									player.seekTo( 0 );
								} else if ( playerState === YT.PlayerState.PAUSED ) {
									player.playVideo();
								}
							} );
						}

						window.onYouTubeIframeAPIReady = function() {
							for ( let callback of onYouTubeIframeAPIReadyCallbacks ) {
								callback();
							}
						};

						window.hideYTActivated = true;
					}
				};

				$( document ).ready( balazs_onboard.on_ready );

			}( jQuery, document ));
		</script>
		<?php
	}

	/**
	 * Add dismiss modal.
	 */
	public static function add_dismiss_modal() {
		?>
		<div class="balazs-onboard-dismiss-modal-overlay"></div>
		<div class="balazs-onboard-dismiss-modal">
			<h3><?php echo wp_kses_post( esc_html__( 'Are you sure?', 'balazs-wssv' ) ); ?></h3>
			<p><?php echo wp_kses_post( esc_html__( "Are you sure you want to dismiss the Get Started tab? You won't be able to access it again.", 'balazs-wssv' ) ); ?></p>
			<div class="balazs-onboard-dismiss-modal__actions">
				<button class="balazs-onboard-dismiss-modal__dismiss button-primary"><?php esc_attr_e( 'Yes', 'balazs-wssv' ); ?></button>
				<button class="balazs-onboard-dismiss-modal__cancel button-link"><?php esc_attr_e( 'Cancel', 'balazs-wssv' ); ?></button>
			</div>
		</div>
		<?php
	}

	/**
	 * Get onboard steps.
	 */
	public static function get_onboard_steps() {
		static $steps = false;

		if ( ! empty( $steps ) ) {
			return $steps;
		}

		$plugin = Balazs_WSSV_Core_Cross_Sells::get_plugin();

		if ( empty( $plugin ) || empty( $plugin['product']['onboarding_steps'] ) ) {
			return false;
		}

		$steps = $plugin['product']['onboarding_steps'];

		return $steps;
	}

	/**
	 * Is "Get Started" dismissed?
	 *
	 * @return bool
	 */
	public static function get_started_is_dismissed() {
		$settings = get_option( Balazs_WSSV_Core_Settings::$args['option_group'] . '_settings', array() );

		return ! empty( $settings['hide_get_started'] );
	}

	/**
	 * Get onboard steps display.
	 */
	public static function get_onboard_steps_display() {
		$steps = self::get_onboard_steps();

		if ( empty( $steps ) ) {
			return false;
		}

		ob_start();
		?>
		<input type="hidden" class="balazs-onboard-hide-get-started" name="<?php echo esc_attr( Balazs_WSSV_Core_Settings::$args['option_group'] ); ?>_settings[hide_get_started]" value="0">
		<ul class="balazs-onboard-steps">
			<?php foreach ( $steps as $step ) { ?>
				<li class="balazs-onboard-steps__step">
					<div class="balazs-onboard-steps__step-content">
						<h4 class="balazs-onboard-steps__step-title"><?php echo wp_kses_post( $step['title'] ); ?></h4>
						<p class="balazs-onboard-steps__step-description"><?php echo wp_kses_post( $step['description'] ); ?></p>
					</div>
					<?php if ( 'link' === $step['type'] ) { ?>
						<a href="<?php echo esc_attr( $step['link'] ); ?>" class="balazs-onboard-steps__step-link"><?php echo wp_kses_post( $step['button_text'] ); ?> <span class="dashicons dashicons-external"></span></a>
					<?php } else { ?>
						<span class="balazs-onboard-steps__step-link"><?php echo wp_kses_post( $step['button_text'] ); ?> <span class="dashicons dashicons-arrow-right-alt"></span></span>
					<?php } ?>
				</li>
				<?php if ( 'content' === $step['type'] && ! empty( $step['content'] ) ) { ?>
					<li class="balazs-onboard-steps__step-body">
						<div class="balazs-onboard-steps__step-body-padding">
							<?php add_filter( 'wp_kses_allowed_html', array( __CLASS__, 'allow_iframe' ), 10 ); ?>
							<?php echo wp_kses_post( $step['content'] ); ?>
							<?php remove_filter( 'wp_kses_allowed_html', array( __CLASS__, 'allow_iframe' ), 10 ); ?>
						</div>
					</li>
				<?php } ?>
			<?php } ?>
			<li class="balazs-onboard-steps__step">
				<div class="balazs-onboard-steps__step-content">
					<p class="balazs-onboard-steps__step-description"><?php echo wp_kses_post( esc_html__( 'Help is at hand if you face any issues.', 'balazs-wssv' ) ); ?></p>
				</div>
					<?php echo wp_kses_post( esc_html__( 'Get Help', 'balazs-wssv' ) ); ?> <span class="dashicons dashicons-external"></span>
				</a>
			</li>
		</ul>
		<?php

		return ob_get_clean();
	}

	/**
	 * Temporarily allow iframes.
	 *
	 * @param array $allowed Allowed tags.
	 *
	 * @return array
	 */
	public static function allow_iframe( $allowed ) {
		$allowed['iframe'] = array(
			'align'        => true,
			'width'        => true,
			'height'       => true,
			'frameborder'  => true,
			'name'         => true,
			'src'          => true,
			'id'           => true,
			'class'        => true,
			'style'        => true,
			'scrolling'    => true,
			'marginwidth'  => true,
			'marginheight' => true,
		);

		return $allowed;
	}

	/**
	 * Format iframe in step content.
	 *
	 * @param string $content Rich content.
	 *
	 * @return string|string[]|null
	 */
	public static function format_iframe( $content ) {
		// Add responsive wrapper.
		$content = str_replace( array( '<iframe', '</iframe>' ), array( '<span class="balazs-onboard-iframe"><iframe allow="fullscreen"', '</iframe></span>' ), $content );

		// Enable API - modify YouTube URL.
		$pattern = '/<iframe.*?s*src="(.*?)".*?<\/iframe>/';
		$content = preg_replace_callback(
			$pattern,
			function ( $match ) {
				$url = add_query_arg(
					array(
						'rel'         => 0,
						'enablejsapi' => 1,
					),
					$match[1]
				);

				return str_replace( $match[1], $url, $match[0] );
			},
			$content
		);

		return $content;
	}
}

// Hide opt-in elements from WordPress admin interface
add_action('admin_head', function() {
    echo '<style>
        .balazsapi-telemetry__title,
        .opt-in-form,
        .balazsapi-opt-in,
        .balazsapi-opt-in-footer,
        .balazsapi-telemetry-modal {
            display: none !important;
        }
    </style>';
});
