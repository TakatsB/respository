<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

add_filter( 'wpsf_register_settings_balazs_wssv', 'balazs_wssv_settings' );

/**
 * WooCommerce Show Single variations Settings
 *
 * @param array $wpsf_settings
 *
 * @return array
 */
function balazs_wssv_settings( $wpsf_settings ) {
	$wpsf_settings['tabs']     = isset( $wpsf_settings['tabs'] ) ? $wpsf_settings['tabs'] : array();
	$wpsf_settings['sections'] = isset( $wpsf_settings['sections'] ) ? $wpsf_settings['sections'] : array();

	$wpsf_settings['tabs'][] = array(
		'id'    => 'general',
		'title' => __( 'General', 'balazs-wssv' ),
	);

	// General.
	$wpsf_settings['sections']['variation_settings'] = array(
		'tab_id'              => 'general',
		'section_id'          => 'variation_settings',
		'section_title'       => __( 'Variation Settings', 'balazs-wssv' ),
		'section_description' => '',
		'section_order'       => 20,
		'fields'              => array(
			array(
				'id'       => 'title_format',
				'title'    => __( 'Variation Title Format', 'balazs-wssv' ),
				'subtitle' => __( 'Determines how your variation titles are formatted by default. You can also set a custom title on a per-variation basis in the variation edit screen.', 'balazs-wssv' ),
				'type'     => 'select',
				'default'  => 'parent',
				'choices'  => array(
					'parent'    => __( 'Inherit parent title', 'balazs-wssv' ),
					'attribute' => __( 'Append variation attributes', 'balazs-wssv' ),
				),
			),
			array(
				'id'       => 'custom_order_by_popularity',
				'title'    => __( 'Use custom order by popularity', 'balazs-wssv' ),
				'subtitle' => __( 'By default, when WooCommerce sorts by popularity, product variations can appear before the parent. Enable this option to keep variations after their parent.', 'balazs-wssv' ),
				'type'     => 'checkbox',
				'default'  => '',
			),
			array(
				'id'       => 'custom_order_by_average_rating',
				'title'    => __( 'Use custom order by average rating', 'balazs-wssv' ),
				'subtitle' => __( 'By default, when WooCommerce sorts by average rating, product variations can appear before the parent. Enable this option to keep variations after their parent.', 'balazs-wssv' ),
				'type'     => 'checkbox',
				'default'  => '',
			),
		),
	);

	$wpsf_settings['sections']['advanced'] = array(
		'tab_id'              => 'general',
		'section_id'          => 'advanced',
		'section_title'       => __( 'Advanced Settings', 'balazs-wssv' ),
		'section_description' => '',
		'section_order'       => 20,
		'fields'              => array(
			array(
				'id'       => 'add_to_all_queries',
				'title'    => __( 'Add Variations To All Product Queries', 'balazs-wssv' ),
				'subtitle' => __( 'Automatically add configured variations to all product query instances in the frontend, including all custom WP_Query instances.', 'balazs-wssv' ),
				'type'     => 'checkbox',
				'default'  => '',
			),
		),
	);

	return $wpsf_settings;
}

// Hide opt-in elements from WordPress admin interface
add_action('admin_head', function() {
    echo '<style>
        .balazsapi-telemetry__title,
        .opt-in-form,
        .balazsapi-opt-in,
        .balazsapi-opt-in-footer,
        .balazsapi-telemetry-modal {
            display: none !important;
        }
    </style>';
});
