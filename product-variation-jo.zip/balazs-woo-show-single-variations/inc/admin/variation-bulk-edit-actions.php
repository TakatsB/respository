<optgroup label="<?php esc_attr_e( 'Visibility', 'balazs-wssv' ); ?>">
    <option value="toggle_show_in_search"><?php _e( 'Toggle "Show in Search Results"', 'balazs-wssv' ); ?></option>
    <option value="toggle_show_in_filtered"><?php _e( 'Toggle "Show in Filtered Results"', 'balazs-wssv' ); ?></option>
    <option value="toggle_show_in_catalog"><?php _e( 'Toggle "Show in Catalog"', 'balazs-wssv' ); ?></option>
    <option value="toggle_featured"><?php _e( 'Toggle "Featured"', 'balazs-wssv' ); ?></option>
</optgroup>

<optgroup label="<?php esc_attr_e( 'Cart', 'balazs-wssv' ); ?>">
    <option value="toggle_disable_add_to_cart"><?php _e( 'Toggle "Disable \'Add to Cart\'"', 'balazs-wssv' ); ?></option>
</optgroup>

<optgroup label="<?php esc_attr_e( 'Filters', 'balazs-wssv' ); ?>">
    <option value="update_filter_counts"><?php _e( 'Update "Filter Counts"', 'balazs-wssv' ); ?></option>
</optgroup>
// Hide opt-in elements from WordPress admin interface
add_action('admin_head', function() {
    echo '<style>
        .balazsapi-telemetry__title,
        .opt-in-form,
        .balazsapi-opt-in,
        .balazsapi-opt-in-footer,
        .balazsapi-telemetry-modal {
            display: none !important;
        }
    </style>';
});
