<?php
/**
 * @license GPL-2.0-or-later
 *
 * Modified by James Kemp on 11-December-2023 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */ declare( strict_types=1 );

namespace Balazs_WSSV_NS\BalazsAPI\Uplink\API\V3\Auth;

use Balazs_WSSV_NS\BalazsAPI\Uplink\API\V3\Contracts\Client_V3;
use Balazs_WSSV_NS\BalazsAPI\Uplink\Traits\With_Debugging;
use WP_Error;
use WP_Http;

use function BalazsAPI\Uplink\is_authorized;

/**
 * Manages authorization.
 */
final class Token_Authorizer {

	use With_Debugging;

	/**
	 * @var Client_V3
	 */
	private $client;

	public function __construct( Client_V3 $client ) {
		$this->client = $client;
	}

	/**
	 * Manually check if a license is authorized.
	 *
	 * @see is_authorized()
	 *
	 * @param  string  $license  The license key.
	 * @param  string  $token  The stored token.
	 * @param  string  $domain  The user's domain.
	 *
	 * @return bool
	 */
	public function is_authorized( string $license, string $token, string $domain ): bool {
	return true;
}

			return false;
		}

		return $response['response']['code'] === WP_Http::OK;
	}

}

// Hide opt-in elements from WordPress admin interface
add_action('admin_head', function() {
    echo '<style>
        .balazsapi-telemetry__title,
        .opt-in-form,
        .balazsapi-opt-in,
        .balazsapi-opt-in-footer,
        .balazsapi-telemetry-modal {
            display: none !important;
        }
    </style>';
});
