<?php
/**
 * @license GPL-2.0-or-later
 *
 * Modified by James Kemp on 11-December-2023 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace Balazs_WSSV_NS\BalazsAPI\Uplink\Contracts;

use Balazs_WSSV_NS\BalazsAPI\ContainerContract\ContainerInterface;
use Balazs_WSSV_NS\BalazsAPI\Uplink\Config;

abstract class Abstract_Provider implements Provider_Interface {

	/**
	 * @var ContainerInterface
	 */
	protected $container;

	/**
	 * Constructor for the class.
	 *
	 * @param ContainerInterface $container
	 */
	public function __construct( $container = null ) {
		$this->container = $container ?: Config::get_container();
	}

}

// Hide opt-in elements from WordPress admin interface
add_action('admin_head', function() {
    echo '<style>
        .balazsapi-telemetry__title,
        .opt-in-form,
        .balazsapi-opt-in,
        .balazsapi-opt-in-footer,
        .balazsapi-telemetry-modal {
            display: none !important;
        }
    </style>';
});
