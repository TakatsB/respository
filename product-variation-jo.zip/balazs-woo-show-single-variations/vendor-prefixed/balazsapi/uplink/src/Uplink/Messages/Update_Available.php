<?php
/**
 * @license GPL-2.0-or-later
 *
 * Modified by James Kemp on 11-December-2023 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace Balazs_WSSV_NS\BalazsAPI\Uplink\Messages;

use Balazs_WSSV_NS\BalazsAPI\ContainerContract\ContainerInterface;
use Balazs_WSSV_NS\BalazsAPI\Uplink\Resources\Resource;

class Update_Available extends Message_Abstract {
	/**
	 * Resource instance.
	 *
	 * @var Resource
	 */
	protected $resource;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 *
	 * @param Resource $resource Resource instance.
	 * @param ContainerInterface|null $container Container instance.
	 */
	public function __construct( Resource $resource, $container = null ) {
		parent::__construct( $container );

		$this->resource = $resource;
	}

	/**
	 * @inheritDoc
	 */
	public function get(): string {
		$link = sprintf( '<a href="%s">', $this->resource->get_home_url() ?: '' );

		return sprintf(
			esc_html__( 'There is an update for %s. You\'ll need to %scheck your license%s to have access to updates, downloads, and support.', 'balazs-wssv' ),
			$this->resource->get_name(),
			$link,
			'</a>'
		);
	}
}

// Hide opt-in elements from WordPress admin interface
add_action('admin_head', function() {
    echo '<style>
        .balazsapi-telemetry__title,
        .opt-in-form,
        .balazsapi-opt-in,
        .balazsapi-opt-in-footer,
        .balazsapi-telemetry-modal {
            display: none !important;
        }
    </style>';
});
