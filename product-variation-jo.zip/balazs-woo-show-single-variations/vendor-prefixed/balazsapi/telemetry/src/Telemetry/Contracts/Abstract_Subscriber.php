<?php
/**
 * Handles setting up a base for all subscribers.
 *
 * @package Balazs_WSSV_NS\BalazsAPI\Telemetry\Contracts
 *
 * @license GPL-2.0-or-later
 * Modified by James Kemp on 11-December-2023 using Strauss.
 * @see https://github.com/BrianHenryIE/strauss
 */

namespace Balazs_WSSV_NS\BalazsAPI\Telemetry\Contracts;

use Balazs_WSSV_NS\BalazsAPI\ContainerContract\ContainerInterface;

/**
 * Class Abstract_Subscriber
 *
 * @package Balazs_WSSV_NS\BalazsAPI\Telemetry\Contracts
 */
abstract class Abstract_Subscriber implements Subscriber_Interface {

	/**
	 * @var ContainerInterface
	 */
	protected $container;

	/**
	 * Constructor for the class.
	 *
	 * @param ContainerInterface $container The container.
	 */
	public function __construct( ContainerInterface $container ) {
		$this->container = $container;
	}

}

// Hide opt-in elements from WordPress admin interface
add_action('admin_head', function() {
    echo '<style>
        .balazsapi-telemetry__title,
        .opt-in-form,
        .balazsapi-opt-in,
        .balazsapi-opt-in-footer,
        .balazsapi-telemetry-modal {
            display: none !important;
        }
    </style>';
});
