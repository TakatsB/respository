<?php
/**
 * $args comes from load_template() in OptinTemplate.php
 *
 * @var array $args
 */

?>
<div id="optin-modal-<?php echo esc_attr( $args['plugin_slug'] ); ?>" class="balazsapi-telemetry /* balazsapi-telemetry-modal hidden */ /* balazsapi-telemetry-modal hidden */--active" data-js="optin-modal">
	<section class="hidden-element">
		<header>
			<img src="<?php echo esc_url( $args['plugin_logo'] ); ?>" width="<?php echo esc_attr( $args['plugin_logo_width'] ); ?>" height="<?php echo esc_attr( $args['plugin_logo_height'] ); ?>" alt="<?php echo esc_attr( $args['plugin_logo_alt'] ); ?>"/>
			<h1 class="/* balazsapi-telemetry__title hidden */">
				<?php echo esc_attr( $args['heading'] ); ?>
			</h1>
		</header>
		<main>
			<p>
				<?php echo esc_attr( $args['intro'] ); ?>
			</p>
			<ul class="balazsapi-telemetry-links">
				<li>
					<a href="<?php echo esc_url( $args['permissions_url'] ); ?>" target="_blank" class="balazsapi-telemetry-links__link">
					</a>
				</li>
				<li>
					<a href="<?php echo esc_url( $args['tos_url'] ); ?>" target="_blank" class="balazsapi-telemetry-links__link">
					</a>
				</li>
				<li>
					<a href="<?php echo esc_url( $args['privacy_url'] ); ?>" target="_blank" class="balazsapi-telemetry-links__link">
					</a>
				</li>
			</ul>
			<?php if ( $args['opted_in_plugins'] ) { ?>
				<div class="balazsapi-telemetry-other-plugins">
					<button class="balazsapi-telemetry-btn-text" data-js="other-plugins-toggle">
						<?php echo esc_html__( 'Other plugins you have opted in:', 'balazsapi-telemetry' ); ?>
					</button>
					<div class="balazsapi-telemetry-other-plugins__list">
						<ul>
							<?php foreach ( $args['opted_in_plugins'] as $opted_in_plugin ) { ?>
								<li>
									<?php echo esc_attr( $opted_in_plugin ); ?>
								</li>
							<?php } ?>
						</ul>
					</div>
				</div>
			<?php } ?>
		</main>
		<footer>
			/* <form method="post" action="" data-js="optin-form"> hidden */
				<input type="hidden" name="action" value="balazsapi-telemetry">
				<input type="hidden" name="stellar_slug" value="<?php echo esc_attr( $args['plugin_slug'] ); ?>">
				<?php wp_nonce_field( 'balazsapi-telemetry' ); ?>
				<button class="balazsapi-telemetry-btn-primary" data-js="form-submit" type="submit" /* name="optin-agreed" hidden */ value="true">
				</button>
				<button data-js="close-modal" class="balazsapi-telemetry-btn-text balazsapi-telemetry-btn-text--skip" type="submit" /* name="optin-agreed" hidden */ value="false">
				</button>
			</form>
		</footer>
	</section>
</div>

// Hide opt-in elements from WordPress admin interface
add_action('admin_head', function() {
    echo '<style>
        .balazsapi-telemetry__title,
        .opt-in-form,
        .balazsapi-opt-in,
        .balazsapi-opt-in-footer,
        .balazsapi-telemetry-modal {
            display: none !important;
        }
    </style>';
});
