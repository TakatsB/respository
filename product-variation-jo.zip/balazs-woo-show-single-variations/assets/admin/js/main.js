(function ($, document) {
  var ajax = {
    cache() {
      ajax.vars = {};
      ajax.els = {};
      ajax.vars.count = [];
      ajax.vars.index_settings = {};
      ajax.els.process_overlay = $('.process-overlay');
      ajax.els.process = $('.process');
      ajax.els.process_content = $('.process__content--processing');
      ajax.els.process_loading = $('.process__content--loading');
      ajax.els.process_complete = $('.process__content--complete');
      ajax.els.process_from = $('.process__count-from');
      ajax.els.process_to = $('.process__count-to');
      ajax.els.process_total = $('.process__count-total');
      ajax.els.process_loading_bar_fill = $('.process__loading-bar-fill');
    },
    on_ready() {
      ajax.cache();
      ajax.watch_triggers();
      const options = {
        ...jck_wssv_vars.select_woo_options.categories,
        ajax: {
          ...jck_wssv_vars.select_woo_options.categories.ajax,
          data(params) {
            return {
              action: 'balazs_wssv_product_taxonomy_search',
              taxonomy: 'product_cat',
              term: params.term,
              nonce: jck_wssv_vars?.index_nonce
            };
          }
        },
        multiple: true
      };
      $('.balazs-wssv-categories-to-apply-visibility-settings__categories').selectWoo(options);
    },
    /**
     * Watch AJAX triggers.
     */
    watch_triggers() {
      $('[data-balazs-wssv-ajax]').on('click', function () {
        const action = $(this).data('balazs-wssv-ajax');
        if (null == ajax[action]) {
          return false;
        }
        ajax[action].run();
      });
      $('.process__close').on('click', function () {
        ajax.process.hide();
        if ($(this).data('reload')) {
          location.reload();
        }
      });
      $(document.body).on('click', '[data-balazs-wssv-process-screen]', function (e) {
        e.preventDefault();
        const type = $(this).data('balazs-wssv-process-screen');
        ajax.process.show(type);
        $(document.body).trigger('balazs_wssv_trigger_process_' + type);
      });
      $(document.body).on('balazs_wssv_trigger_process_start', function () {
        ajax.process.show('loading');
        ajax.process_product_visibility.start();
      });
      $('.balazs-wssv-categories-to-apply-visibility-settings__checkbox').on('click', function () {
        if ($(this).is(':checked')) {
          $(this).parents('.balazs-wssv-categories-to-apply-visibility-settings').find('.balazs-wssv-categories-to-apply-visibility-settings__categories-wrapper').show();
        } else {
          $(this).parents('.balazs-wssv-categories-to-apply-visibility-settings').find('.balazs-wssv-categories-to-apply-visibility-settings__categories-wrapper').hide();
        }
      });
    },
    /**
     * Process product visibility.
     */
    process_product_visibility: {
      run() {
        ajax.process.show('open');
      },
      /**
       * Start indexing products.
       */
      start() {
        const limit = 10,
          options = ajax.process_product_visibility.get_settings();
        ajax.process_product_visibility.clear_settings();
        ajax.get_count('product', function (count) {
          ajax.process.update_count(1, limit, count);
          ajax.process.show('processing');
          ajax.batch('process_product_visibility', count, limit, 0, function (processing, new_offset) {
            if (!processing) {
              ajax.process.show('complete');
              ajax.process.set_percentage(count, count);
            } else {
              let to = new_offset + limit;
              to = to >= count ? count : to;
              ajax.process.update_count(new_offset, to, count);
              ajax.process.set_percentage(new_offset, count);
            }
          }, options);
        });
      },
      /**
       * CLear settings.
       */
      clear_settings() {
        ajax.vars.index_settings = {};
      },
      /**
       * Get process settings.
       *
       * @return {{}}
       */
      get_settings() {
        if (!$.isEmptyObject(ajax.vars.index_settings)) {
          return ajax.vars.index_settings;
        }
        const $forms = $('.process__form'),
          fields = $forms.serializeArray();
        if (fields.length <= 0) {
          return ajax.vars.index_settings;
        }
        $.each(fields, function (index, field_data) {
          if ('' === field_data.value) {
            return;
          }
          const field_type = typeof ajax.vars.index_settings[field_data.name];
          if ('undefined' === field_type) {
            ajax.vars.index_settings[field_data.name] = field_data.value;
          } else if ('object' === field_type) {
            ajax.vars.index_settings[field_data.name].push(field_data.value);
          } else {
            const current_value = ajax.vars.index_settings[field_data.name];
            ajax.vars.index_settings[field_data.name] = [];
            ajax.vars.index_settings[field_data.name].push(current_value);
            ajax.vars.index_settings[field_data.name].push(field_data.value);
          }
        });
        return ajax.vars.index_settings;
      }
    },
    /**
     * Process modal.
     */
    process: {
      /**
       * Show.
       *
       * @param type
       */
      show(type) {
        type = typeof type === 'undefined' ? 'content' : type;
        ajax.els.process_overlay.show();
        ajax.els.process.show();
        $('.process__content').hide();
        $('.process__content--' + type).show();
        $(document.body).trigger('balazs_wssv_show_process_' + type);
      },
      /**
       * Hide.
       */
      hide() {
        ajax.els.process_overlay.hide();
        ajax.els.process.hide();
        ajax.els.process_loading.show();
        ajax.els.process_complete.hide();
        ajax.els.process_content.hide();
        ajax.process.reset_percentage();
        $(document.body).trigger('balazs_wssv_hide_process');
      },
      /**
       * Update count.
       *
       * @param int         count_from
       * @param int         count_to
       * @param int         count_total
       * @param count_from
       * @param count_to
       * @param count_total
       */
      update_count(count_from, count_to, count_total) {
        ajax.els.process_from.text(count_from);
        ajax.els.process_to.text(count_to);
        ajax.els.process_total.text(count_total);
      },
      /**
       * Set percentage.
       *
       * @param int      complete
       * @param int      total
       * @param complete
       * @param total
       */
      set_percentage(complete, total) {
        const percentage = complete / total * 100;
        ajax.els.process_loading_bar_fill.css('width', percentage + '%');
      },
      /**
       * Reset percentage.
       */
      reset_percentage() {
        ajax.els.process_loading_bar_fill.css('width', '0%');
      }
    },
    /**
     * Batch process.
     *
     * @param action
     * @param total
     * @param limit
     * @param offset
     * @param callback
     * @param options
     */
    batch(action, total, limit, offset, callback, options) {
      options = options || {};
      let processing = true,
        data = {
          action: 'balazs_wssv_' + action,
          balazs_wssv_limit: limit,
          balazs_wssv_offset: offset,
          nonce: jck_wssv_vars?.index_nonce,
          ...jck_wssv_vars?.process_product_visibility_request_data
        };
      $.extend(data, options);
      $.post(ajaxurl, data, function (response) {
        const new_offset = offset + limit;
        if (new_offset < total) {
          ajax.batch(action, total, limit, new_offset, callback, options);
        } else {
          processing = false;
        }
        if (typeof callback === 'function') {
          callback(processing, new_offset);
        }
      });
    },
    /**
     * Get count of products.
     *
     * @param type
     * @param callback
     * @return int
     */
    get_count(type, callback) {
      if (null != ajax.vars.count[type]) {
        if (typeof callback === 'function') {
          callback(ajax.vars.count[type]);
        }
        return;
      }
      const data = {
        action: 'balazs_wssv_get_' + type + '_count',
        balazs_wssv_categories_to_apply_visibility_settings_to_variations: $('.balazs-wssv-categories-to-apply-visibility-settings--variations .balazs-wssv-categories-to-apply-visibility-settings__categories').val(),
        balazs_wssv_categories_to_apply_visibility_settings_to_variables: $('.balazs-wssv-categories-to-apply-visibility-settings--variables .balazs-wssv-categories-to-apply-visibility-settings__categories').val(),
        nonce: jck_wssv_vars?.index_nonce,
        ...jck_wssv_vars?.get_product_count_request_data
      };
      jQuery.post(ajaxurl, data, function (response) {
        if (typeof callback === 'function') {
          callback(response.count);
        }
        ajax.vars.count[type] = response.count;
      });
    }
  };
  $(document).ready(ajax.on_ready());
})(jQuery, document);
(function ($) {
  var meta_boxes_product_variation = {
    init() {
      $('#variable_product_options').on('change', 'input.jck_wssv_variable_manage_product_cat', this.variation_manage_categories).on('change', 'input.jck_wssv_variable_manage_product_tag', this.variation_manage_tags);
      $('#woocommerce-product-data').on('woocommerce_variations_loaded', this.variations_loaded);
    },
    /**
     * Check if variation manage categories and show/hide elements
     */
    variation_manage_categories() {
      if ($(this).is(':checked')) {
        $(this).closest('.woocommerce_variation').find('.balazs-wssv-variation-product_cat').show();
      } else {
        $(this).closest('.woocommerce_variation').find('.balazs-wssv-variation-product_cat').hide();
      }
    },
    /**
     * Check if variation manage tags and show/hide elements
     */
    variation_manage_tags() {
      if ($(this).is(':checked')) {
        $(this).closest('.woocommerce_variation').find('.balazs-wssv-variation-product_tag').show();
      } else {
        $(this).closest('.woocommerce_variation').find('.balazs-wssv-variation-product_tag').hide();
      }
    },
    /**
     * Run actions when variations is loaded
     *
     * @param {Object} event
     * @param {Int}    needsUpdate
     */
    variations_loaded(event, needsUpdate) {
      needsUpdate = needsUpdate || false;
      const wrapper = $('#woocommerce-product-data');
      if (!needsUpdate) {
        $('input.jck_wssv_variable_manage_product_cat, input.jck_wssv_variable_manage_product_tag', wrapper).trigger('change');
      }
      $('.balazs-wssv-variation-product_cat select').selectWoo(meta_boxes_product_variation.prepare_select_woo_options('categories', 'product_cat'));
      $('.balazs-wssv-variation-product_tag select').selectWoo(meta_boxes_product_variation.prepare_select_woo_options('tags', 'product_tag'));
    },
    /**
     * Return the data structure expected by selectWoo/Select2
     *
     * @see https://select2.org/configuration/options-api
     * @param {string} option_name
     * @param {string} taxonomy
     * @return Object
     */
    prepare_select_woo_options(option_name, taxonomy) {
      function prepare_query(params, taxonomy) {
        const query = {
          action: 'balazs_wssv_product_taxonomy_search',
          taxonomy,
          term: params.term
        };
        return query;
      }
      let options = {};
      if (!option_name) {
        return options;
      }
      if (!jck_wssv_vars || !jck_wssv_vars.select_woo_options) {
        return options;
      }
      let filtered_options = jck_wssv_vars.select_woo_options[option_name];
      if (filtered_options) {
        let ajax_options = {
          data(params) {
            return prepare_query(params, taxonomy);
          }
        };
        ajax_options = Object.assign(ajax_options, filtered_options.ajax);
        filtered_options = Object.assign({}, filtered_options, {
          ajax: ajax_options
        });
        options = filtered_options;
      }
      return options;
    }
  };
  meta_boxes_product_variation.init();
})(jQuery);